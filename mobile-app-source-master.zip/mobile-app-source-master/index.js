import Application from './src';

const App = new Application();
