# Payments
1) At the moment, the application, supports payments with these templates:
cc.tpl, cc_outside.tpl, check.tpl, paypal_express.tpl, phone.tpl

2) Payments with other templates are not displayed.

3) The first payment on the list is selected by default.
