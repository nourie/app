import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import cloneDeep from 'lodash/cloneDeep';
import EStyleSheet from 'react-native-extended-stylesheet';
import * as t from 'tcomb-form-native';

// Import actions.
import * as productsActions from '../actions/productsActions';

import Button from '../components/Button';
import Spinner from '../components/Spinner';
import Icon from '../components/Icon';
import {
  iconsMap,
  iconsLoaded,
} from '../utils/navIcons';

import theme from '../config/theme';
import i18n from '../utils/i18n';

import {
  DISCUSSION_COMMUNICATION,
  DISCUSSION_RATING,
} from '../constants';

const styles = EStyleSheet.create({
  container: {
    backgroundColor: '$screenBackgroundColor',
    padding: 14,
  },
  wrapperStyle: {
    flex: 1,
  }
});

const inputStyle = cloneDeep(t.form.Form.stylesheet);
// overriding the text color
inputStyle.textbox.normal = {
  ...inputStyle.textbox.normal,
  height: 130,
  textAlign: 'left',
};
inputStyle.textbox.error = {
  ...inputStyle.textbox.error,
  height: 130,
  textAlign: 'left',
};
inputStyle.controlLabel.normal = {
  ...inputStyle.controlLabel.normal,
  textAlign: 'left',
};
inputStyle.controlLabel.error = {
  ...inputStyle.controlLabel.error,
  textAlign: 'left',
};

function selectRatingTemplate(rating) {
  const containerStyle = {
    marginTop: 8,
    marginBottom: 20,
  };
  const wrapperStyle = {
    flex: 1,
    flexDirection: 'row',
  };
  const errorTextStyle = {
    color: '#a94442',
    fontSize: 16,
  };
  const checkIcon = {
    color: theme.$ratingStarsColor,
  };

  const stars = [];
  const currentRating = Math.round(rating.value || 0);

  for (let i = 1; i <= currentRating; i += 1) {
    stars.push(// eslint-disable-line
      <TouchableOpacity key={`star_${i}`} onPress={() => rating.onChange(i)}>
        <Icon name="star" style={checkIcon} />
      </TouchableOpacity>
    );// eslint-disable-line
  }

  for (let r = stars.length; r <= 4; r += 1) {
    stars.push( // eslint-disable-line
      <TouchableOpacity key={`star_border_${r}`} onPress={() => rating.onChange(r + 1)}>
        <Icon name="star-border" style={checkIcon} />
      </TouchableOpacity>
    ); // eslint-disable-line
  }

  return (
    <View style={containerStyle}>
      <View style={wrapperStyle}>
        {stars}
      </View>
      {rating.hasError &&
        <Text style={errorTextStyle}>
          {i18n.gettext('The rating field is mandatory.')}
        </Text>
      }
    </View>
  );
}

class WriteReview extends Component {
  static propTypes = {
    navigator: PropTypes.shape({
      push: PropTypes.func,
      pop: PropTypes.func,
      dismissModal: PropTypes.func,
      setOnNavigatorEvent: PropTypes.func,
    }),
    type: PropTypes.string,
    discussionId: PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
    ]),
    discussionType: PropTypes.string,
    activeDiscussion: PropTypes.shape({}),
    productsActions: PropTypes.shape({
      postDiscussion: PropTypes.func,
    }),
    discussion: PropTypes.shape({
      posts: PropTypes.arrayOf(PropTypes.shape({})),
      isNewPostSent: PropTypes.bool,
    }),
  };

  static navigatorStyle = {
    navBarBackgroundColor: theme.$navBarBackgroundColor,
    navBarButtonColor: theme.$navBarButtonColor,
    navBarButtonFontSize: theme.$navBarButtonFontSize,
    navBarTextColor: theme.$navBarTextColor,
    screenBackgroundColor: theme.$screenBackgroundColor,
  };

  constructor(props) {
    super(props);
    this.isNewPostSent = false;

    props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));
  }

  componentWillMount() {
    const { navigator } = this.props;
    if (this.props.type === 'modal') {
      iconsLoaded.then(() => {
        navigator.setButtons({
          leftButtons: [
            {
              id: 'close',
              icon: iconsMap.close,
            },
          ],
        });
      });
    }

    navigator.setTitle({
      title: i18n.gettext('Write a Review').toUpperCase(),
    });
  }

  componentWillReceiveProps(nextProps) {
    const { navigator } = this.props;
    if (this.isNewPostSent) {
      this.isNewPostSent = false;
      if (nextProps.type === 'modal') {
        navigator.dismissModal();
      } else {
        navigator.pop();
      }
    }
  }

  onNavigatorEvent(event) {
    const { navigator } = this.props;
    if (event.type === 'NavBarButtonPress') {
      if (event.id === 'close') {
        navigator.dismissModal();
      }
    }
  }

  handleSend() {
    const {
      productsActions,
      activeDiscussion,
      discussionType,
      discussionId,
    } = this.props;
    const value = this.refs.form.getValue(); // eslint-disable-line
    if (value) {
      this.isNewPostSent = true;
      productsActions.postDiscussion({
        thread_id: activeDiscussion.thread_id,
        name: value.name,
        rating_value: value.rating,
        message: value.message,
        discussionType,
        discussionId,
      });
    }
  }

  render() {
    const { discussion, activeDiscussion } = this.props;
    const Rating = t.enums({
      1: '1',
      2: '2',
      3: '3',
      4: '4',
      5: '5',
    }, '1');

    // eslint-disable-next-line
    const Form = t.form.Form;
    let FormFields = null;

    switch (activeDiscussion.type) {
      case DISCUSSION_COMMUNICATION:
        FormFields = t.struct({
          name: t.String,
          message: t.String,
        });
        break;

      case DISCUSSION_RATING:
        FormFields = t.struct({
          name: t.String,
          rating: Rating,
        });
        break;

      default:
        FormFields = t.struct({
          name: t.String,
          rating: Rating,
          message: t.String,
        });
        break;
    }
    const options = {
      disableOrder: true,
      fields: {
        name: {
          label: i18n.gettext('Your name'),
          clearButtonMode: 'while-editing',
        },
        rating: {
          template: selectRatingTemplate,
        },
        message: {
          numberOfLines: 4,
          multiline: true,
          stylesheet: inputStyle,
          label: i18n.gettext('Your message'),
          clearButtonMode: 'while-editing',
        },
      }
    };

    return (
      <ScrollView style={styles.wrapperStyle} contentContainerStyle={styles.container}>
        <Form
          ref="form" // eslint-disable-line
          type={FormFields}
          options={options}
        />
        <Button type="primary" onPress={() => this.handleSend()}>
          {i18n.gettext('Send review').toUpperCase()}
        </Button>
        <Spinner visible={discussion.fetching} />
      </ScrollView>
    );
  }
}

export default connect(
  state => ({
    discussion: state.discussion,
    productDetail: state.productDetail,
  }),
  dispatch => ({
    productsActions: bindActionCreators(productsActions, dispatch),
  })
)(WriteReview);
