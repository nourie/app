import React from 'react';
import Icon from 'react-native-vector-icons/MaterialIcons';

const MyIcon = props => (<Icon size={30} {...props} />);

export default MyIcon;
